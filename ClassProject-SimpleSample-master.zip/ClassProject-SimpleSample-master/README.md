# Class Project - Simple Sample

Has two scenes:

* **NoGameController** - Shows how you can make a really simple game without a Game Controller script.

* **GameController** - Shows how using a Game Controller script can simplify and allow for easier modification and expansion of a game.